Deck ROM Sync - Deck setup
===========================

1. Copy this whole folder onto your Steam Deck (USB drive, network share,
   or just download it directly on the Deck in Desktop Mode).
2. In Desktop Mode, double-click "Install Deck ROM Sync.desktop".
   - First time only: KDE will ask if you want to "Trust & Launch" it -
     click yes, that's the standard one-time warning for any downloaded
     app, not something specific to this one.
3. Follow the on-screen prompts (it may ask you to set a Deck login
   password if you don't have one yet - needed for SSH).
4. Done. A "Deck ROM Sync - Connect Info" icon now sits on your Desktop -
   double-click it any time to see your Deck's IP address and the exact
   values to type into Deck ROM Sync's Settings on your PC.

Full documentation: see README.md in the main Deck ROM Sync download, or
https://github.com/Tatsuota (portfolio link).

Nothing here ever downloads BIOS/firmware, uses pip, or touches anything
outside your home directory - safe to re-run any time.
