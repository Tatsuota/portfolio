#!/usr/bin/env bash
# install-on-deck.sh - one-click setup for Deck ROM Sync, run ON the Steam Deck.
#
# Normally you never run this file directly - double-click the
# "Install Deck ROM Sync.desktop" icon next to it in Desktop Mode (a bare
# .sh isn't reliably double-click-executable on KDE, so the .desktop file
# opens a terminal and runs this for you). It is safe to re-run any time -
# every step below checks before it changes anything.
#
# What this does:
#   1. Creates ~/Emulation/roms and ~/Emulation/bios if they don't exist.
#   2. Checks whether this account has a login password set (SSH password
#      auth needs one) and offers to open 'passwd' for you if not.
#   3. Enables and starts sshd so the PC app can connect.
#   4. Installs deck_companion.py and deck_connect.py into
#      ~/.local/share/deck-rom-sync/ - your home directory, not a system
#      path, so this survives SteamOS updates. No pip, ever: SteamOS's
#      filesystem is immutable and pip installs wouldn't survive an update
#      anyway, so everything here is bash + tools SteamOS/KDE already ship
#      (systemctl, sudo/pkexec, passwd, kdialog/zenity if present, python3).
#   5. Drops a "Deck ROM Sync - Connect Info" icon on the Desktop (and in
#      the app menu) so you can see this Deck's IP/SSH status any time,
#      and refreshes this installer's own Desktop icon so it's easy to
#      re-run later straight from the installed copy.
#
# After this first run, the PC app re-uploads deck_companion.py,
# deck_connect.py, and this script automatically on every successful
# connect - so future updates ride along for free with no extra steps.

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.local/share/deck-rom-sync"
DESKTOP_DIR="$HOME/Desktop"
APPS_DIR="$HOME/.local/share/applications"
EMU_DIR="$HOME/Emulation"

log()  { echo "[deck-rom-sync] $*"; }
warn() { echo "[deck-rom-sync] WARNING: $*" >&2; }
have() { command -v "$1" >/dev/null 2>&1; }

# Best-effort dialog with a console fallback - never fails silently even if
# neither kdialog nor zenity is installed.
notify() {
    local title="$1" msg="$2"
    if have kdialog; then
        kdialog --title "$title" --msgbox "$msg" >/dev/null 2>&1 || true
    elif have zenity; then
        zenity --info --title="$title" --text="$msg" >/dev/null 2>&1 || true
    else
        echo
        echo "== $title =="
        echo "$msg"
        echo
    fi
}

# Echoes 0 (yes) or 1 (no) via return code. Falls back to a y/N console
# prompt (defaulting to no) if there's no dialog tool available.
ask_yesno() {
    local title="$1" msg="$2"
    if have kdialog; then
        kdialog --title "$title" --yesno "$msg" >/dev/null 2>&1
        return $?
    elif have zenity; then
        zenity --question --title="$title" --text="$msg" >/dev/null 2>&1
        return $?
    else
        echo
        echo "== $title =="
        echo "$msg"
        read -r -p "y/N: " reply
        [[ "$reply" =~ ^[Yy]$ ]]
    fi
}

# Copies $1 -> $2 unless they already resolve to the same file (matters
# because a re-run launched from the INSTALLED copy in $INSTALL_DIR would
# otherwise try to copy a file onto itself).
copy_if_different() {
    local src="$1" dst="$2"
    local rsrc rdst
    rsrc="$(readlink -f "$src" 2>/dev/null || echo "$src")"
    rdst="$(readlink -f "$dst" 2>/dev/null || echo "$dst")"
    if [[ "$rsrc" != "$rdst" ]]; then
        cp -f "$src" "$dst"
    fi
}

echo "=============================================="
echo " Deck ROM Sync - one-click Deck setup"
echo "=============================================="
echo

# ---------------------------------------------------------- 1. ROM folders
log "Checking ~/Emulation folders..."
mkdir -p "$EMU_DIR/roms" "$EMU_DIR/bios"
log "  roms: $EMU_DIR/roms"
log "  bios: $EMU_DIR/bios"

# ---------------------------------------------------- 2. deck user password
log "Checking whether a login password is set..."
PW_STATUS=""
if PW_LINE="$(passwd -S "$(whoami)" 2>/dev/null)"; then
    PW_STATUS="$(awk '{print $2}' <<<"$PW_LINE")"
fi
case "$PW_STATUS" in
    P)
        log "  Password already set."
        ;;
    NP|L)
        log "  No usable login password set yet - SSH password login needs one."
        if ask_yesno "Deck ROM Sync setup" \
            "Your Deck account has no login password yet.\n\nSSH (used by Deck ROM Sync on your PC) needs one to log in with a password.\n\nOpen a terminal to set it now with 'passwd'?\n\n(Skip this if you plan to use an SSH key instead - see README.)"; then
            if have konsole; then
                konsole -e bash -c 'echo "Set a password for this Deck account (used for SSH):"; passwd; echo; read -p "Press Enter to close..."'
            else
                notify "Deck ROM Sync setup" "Open a terminal yourself and run: passwd"
            fi
        else
            log "  Skipped - run 'passwd' in a terminal any time before syncing, or set up an SSH key instead."
        fi
        ;;
    *)
        log "  Could not determine password status (harmless - continuing). If SSH login fails later, run 'passwd' once."
        ;;
esac

# ------------------------------------------------------------------- 3. sshd
log "Checking sshd..."
if systemctl is-active --quiet sshd; then
    log "  sshd is already running."
else
    log "  sshd is not running - attempting to enable it..."
    ENABLED=0
    if sudo -n systemctl enable --now sshd >/dev/null 2>&1; then
        ENABLED=1
    elif have pkexec && pkexec systemctl enable --now sshd >/dev/null 2>&1; then
        ENABLED=1
    fi
    if [[ "$ENABLED" == "1" ]] && systemctl is-active --quiet sshd; then
        log "  sshd enabled and running."
    else
        warn "Could not enable sshd automatically (no passwordless sudo, and no pkexec prompt succeeded)."
        notify "Deck ROM Sync setup" \
            "Could not turn on SSH automatically.\n\nOpen a terminal and run:\n\n  sudo systemctl enable --now sshd\n\nThen reopen 'Deck ROM Sync - Connect Info' to confirm it's running."
    fi
fi

# ---------------------------------------------------- 4. install Deck tools
log "Installing Deck ROM Sync tools to $INSTALL_DIR ..."
mkdir -p "$INSTALL_DIR"
COPIED=0
for f in deck_companion.py deck_connect.py; do
    src="$SCRIPT_DIR/$f"
    dst="$INSTALL_DIR/$f"
    if [[ -f "$src" ]]; then
        copy_if_different "$src" "$dst"
        chmod +x "$dst" 2>/dev/null || true
        COPIED=$((COPIED + 1))
    else
        warn "$f not found next to this installer - skipping (it will still arrive automatically the first time you sync from the PC app)."
    fi
done
copy_if_different "$SCRIPT_DIR/install-on-deck.sh" "$INSTALL_DIR/install-on-deck.sh" 2>/dev/null || true
chmod +x "$INSTALL_DIR/install-on-deck.sh" 2>/dev/null || true
log "  installed $COPIED tool file(s)."

# --------------------------------------------------- 5. Desktop launchers
log "Creating Desktop launchers..."
mkdir -p "$DESKTOP_DIR" "$APPS_DIR"

write_desktop_file() {
    local dest="$1" name="$2" comment="$3" exec_line="$4" icon="$5"
    {
        echo "[Desktop Entry]"
        echo "Type=Application"
        echo "Name=$name"
        echo "Comment=$comment"
        echo "Exec=$exec_line"
        echo "Icon=$icon"
        echo "Terminal=true"
        echo "Categories=Utility;"
        echo "X-KDE-StartupNotify=true"
    } > "$dest"
    chmod +x "$dest"
}

CONNECT_EXEC="python3 \"$INSTALL_DIR/deck_connect.py\""
for dest in "$DESKTOP_DIR/Deck ROM Sync - Connect Info.desktop" \
            "$APPS_DIR/deck-rom-sync-connect-info.desktop"; do
    write_desktop_file "$dest" "Deck ROM Sync - Connect Info" \
        "Shows this Deck's IP, SSH status, and paths for pairing with Deck ROM Sync on your PC" \
        "$CONNECT_EXEC" "network-wired"
done

INSTALLER_EXEC="bash \"$INSTALL_DIR/install-on-deck.sh\""
for dest in "$DESKTOP_DIR/Install Deck ROM Sync.desktop" \
            "$APPS_DIR/deck-rom-sync-install.desktop"; do
    write_desktop_file "$dest" "Install Deck ROM Sync" \
        "Re-run Deck ROM Sync's one-time Deck setup (safe to run again any time)" \
        "$INSTALLER_EXEC" "system-software-install"
done

log "  Desktop icon: $DESKTOP_DIR/Deck ROM Sync - Connect Info.desktop"
log "  App menu entries added too."

# --------------------------------------------------------------------- done
echo
echo "=============================================="
IP_HINT="$(hostname -I 2>/dev/null | awk '{print $1}')"
if [[ -n "$IP_HINT" ]]; then
    echo " Setup complete. This Deck's IP looks like: $IP_HINT"
else
    echo " Setup complete."
fi
echo " Double-click the new 'Deck ROM Sync - Connect Info' icon on your"
echo " Desktop any time to see everything Deck ROM Sync on your PC needs."
echo "=============================================="
notify "Deck ROM Sync setup" \
    "Setup complete!\n\nDouble-click the new 'Deck ROM Sync - Connect Info' icon on your Desktop for your IP address, SSH status, and the exact values to enter on your PC (Settings)."
