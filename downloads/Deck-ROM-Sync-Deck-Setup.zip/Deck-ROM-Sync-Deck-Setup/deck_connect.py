#!/usr/bin/env python3
"""
Deck Connect Info - runs ON the Steam Deck.

Shows everything Deck ROM Sync's PC app needs to pair with this Deck: IP
address(es), hostname, SSH port, username, whether sshd is running (with a
one-click way to turn it on if not), and the ROMs/BIOS paths - so pairing is
copy-what-you-see instead of guessing.

Uses ONLY the Python standard library - no pip, ever. SteamOS's filesystem
is immutable and pip installs don't survive an update, so this (like
deck_companion.py) only ever touches your home directory and only ever
calls tools that already ship with SteamOS/KDE Plasma (systemctl, ip,
sudo/pkexec, kdialog/zenity).

Display prefers kdialog (ships with KDE Plasma / SteamOS), falls back to
zenity, falls back to a plain formatted print if neither is installed.

Usage:
    python3 deck_connect.py            # show the info dialog (normal use)
    python3 deck_connect.py --json     # machine-readable, no dialogs, no
                                        # side effects - used by the PC app
                                        # for its "Show Deck Info" button
    python3 deck_connect.py --selftest # run offline parsing checks against
                                        # fixture strings (no real Deck
                                        # needed - see bottom of this file)

Normally launched from its own Desktop icon (installed by
install-on-deck.sh), so this is one double-click from Desktop Mode.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile

SSH_PORT = 22
ROMS_PATH = "~/Emulation/roms"
BIOS_PATH = "~/Emulation/bios"


# --------------------------------------------------------------- gathering

def get_hostname() -> str:
    try:
        return socket.gethostname()
    except Exception:
        pass
    try:
        out = subprocess.run(["hostname"], capture_output=True, text=True, timeout=5)
        return out.stdout.strip() or "steamdeck"
    except Exception:
        return "steamdeck"


def get_username() -> str:
    # os.getlogin() commonly raises when there's no controlling tty - which
    # is exactly the case when the PC app invokes this over a non-interactive
    # SSH exec_command for --json, so it's tried first but never relied on.
    try:
        name = os.getlogin()
        if name:
            return name
    except Exception:
        pass
    name = os.environ.get("USER") or os.environ.get("LOGNAME")
    if name:
        return name
    try:
        out = subprocess.run(["whoami"], capture_output=True, text=True, timeout=5)
        name = out.stdout.strip()
        if name:
            return name
    except Exception:
        pass
    return "deck"


_IP_LINE_RE = re.compile(r'^\d+:\s+(\S+?)(?:@\S+)?\s+inet\s+(\d+\.\d+\.\d+\.\d+)/\d+')


def classify_iface(name: str) -> str:
    """Best-effort wired/Wi-Fi/other label from a Linux interface name
    (e.g. 'eth0'/'enp2s0' -> Wired, 'wlan0'/'wlp1s0' -> Wi-Fi)."""
    n = name.lower()
    if n.startswith("lo"):
        return "Loopback"
    if n.startswith(("wl", "wifi")):
        return "Wi-Fi"
    if n.startswith(("en", "eth")):
        return "Wired"
    return "Other"


def parse_ip_addr_output(text: str):
    """Parse `ip -o addr show` text -> list of (iface, ip, kind), skipping
    loopback and anything that isn't an IPv4 address. Pure function so it
    can be exercised by _selftest() against fixture strings without a real
    Deck."""
    results = []
    for line in text.splitlines():
        m = _IP_LINE_RE.match(line.strip())
        if not m:
            continue
        iface, ip = m.group(1), m.group(2)
        kind = classify_iface(iface)
        if kind == "Loopback" or ip.startswith("127."):
            continue
        results.append((iface, ip, kind))
    return results


def get_ip_addresses():
    """Return [(iface, ip, kind), ...] for every non-loopback IPv4 address.
    Tries `ip -o addr show` first (gives interface names, so wired/Wi-Fi can
    be labeled); falls back to `hostname -I` (just an IP list, no names) if
    `ip` isn't available for some reason."""
    try:
        out = subprocess.run(["ip", "-o", "addr", "show"], capture_output=True,
                              text=True, timeout=5)
        if out.returncode == 0 and out.stdout.strip():
            parsed = parse_ip_addr_output(out.stdout)
            if parsed:
                return parsed
    except Exception:
        pass
    try:
        out = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=5)
        ips = out.stdout.split()
        return [("?", ip, "Unknown") for ip in ips if not ip.startswith("127.")]
    except Exception:
        return []


def parse_sshd_status(text: str) -> str:
    """`systemctl is-active sshd` prints exactly one word to stdout
    ('active', 'inactive', 'failed', ...) - split out as a pure function so
    _selftest() can check it against fixtures."""
    return text.strip() or "unknown"


def sshd_status() -> str:
    try:
        out = subprocess.run(["systemctl", "is-active", "sshd"],
                              capture_output=True, text=True, timeout=5)
        return parse_sshd_status(out.stdout)
    except Exception:
        return "unknown"


def gather_info() -> dict:
    """Everything the PC app's 'Show Deck Info' button needs, as plain
    JSON-serializable data. No dialogs, no side effects - safe to call over
    a non-interactive SSH exec_command."""
    return {
        "hostname": get_hostname(),
        "username": get_username(),
        "ip_addresses": [{"iface": i, "ip": ip, "kind": k} for i, ip, k in get_ip_addresses()],
        "ssh_port": SSH_PORT,
        "sshd_status": sshd_status(),
        "roms_path": ROMS_PATH,
        "bios_path": BIOS_PATH,
    }


# ----------------------------------------------------------- enabling sshd

def _have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _sudo_passwordless() -> bool:
    try:
        r = subprocess.run(["sudo", "-n", "true"], capture_output=True, timeout=5)
        return r.returncode == 0
    except Exception:
        return False


def enable_sshd():
    """Try to enable+start sshd. Returns (ok, message). Tries, in order:
    passwordless sudo (SteamOS's 'deck' account has this by default),
    pkexec (graphical polkit password prompt - ships with KDE Plasma), then
    gives up with plain instructions rather than failing silently."""
    cmd = ["systemctl", "enable", "--now", "sshd"]
    if _sudo_passwordless():
        try:
            r = subprocess.run(["sudo", "-n"] + cmd, capture_output=True, text=True, timeout=30)
            if r.returncode == 0:
                return True, "sshd enabled and started."
        except Exception:
            pass
    if _have("pkexec"):
        try:
            r = subprocess.run(["pkexec"] + cmd, capture_output=True, text=True, timeout=60)
            if r.returncode == 0:
                return True, "sshd enabled and started."
        except Exception:
            pass
    return False, (
        "Could not enable sshd automatically. Open Konsole and run:\n\n"
        "  sudo systemctl enable --now sshd\n\n"
        "(If sudo asks for a password you don't have, set one for this "
        "account first with the 'passwd' command.)"
    )


# --------------------------------------------------------------- display

def build_info_text():
    """Returns (text, sshd_status_word)."""
    host = get_hostname()
    user = get_username()
    ips = get_ip_addresses()
    status = sshd_status()

    lines = [
        "Deck ROM Sync - Connect Info",
        "=" * 32,
        "",
        "Enter these into Deck ROM Sync on your PC -> Settings:",
        "",
    ]
    if ips:
        for iface, ip, kind in ips:
            tag = f" ({kind}, {iface})" if iface != "?" else f" ({kind})"
            lines.append(f"  Steam Deck IP / hostname : {ip}{tag}")
    else:
        lines.append("  Steam Deck IP / hostname : (none found - check your network connection)")
    lines.append(f"  SSH port                 : {SSH_PORT}")
    lines.append(f"  Deck username            : {user}")
    lines.append(f"  Deck ROMs path            : {ROMS_PATH}")
    lines.append(f"  Deck BIOS path            : {BIOS_PATH}")
    lines.append("")
    lines.append(f"  Hostname                 : {host}")
    status_word = {"active": "RUNNING", "inactive": "STOPPED", "failed": "FAILED"}.get(status, status.upper())
    lines.append(f"  SSH server (sshd)        : {status_word}")
    if status != "active":
        lines.append("")
        lines.append("  SSH is not running yet - the PC app can't connect until it is.")
    lines.append("")
    lines.append("Tip: if the IP above changes later (e.g. you switch networks),")
    lines.append("just reopen this app and update Settings on the PC.")
    return "\n".join(lines), status


def show_kdialog(text: str, offer_enable: bool) -> None:
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write(text)
        path = f.name
    try:
        subprocess.run(["kdialog", "--title", "Deck ROM Sync", "--textbox", path, "560", "480"])
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    if offer_enable:
        yes = subprocess.run(
            ["kdialog", "--title", "Deck ROM Sync", "--yesno",
             "SSH is not running yet, so the PC app can't connect.\n\n"
             "Enable and start it now?"]).returncode == 0
        if yes:
            ok, msg = enable_sshd()
            subprocess.run(["kdialog", "--title", "Deck ROM Sync",
                             "--msgbox" if ok else "--sorry", msg])


def show_zenity(text: str, offer_enable: bool) -> None:
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write(text)
        path = f.name
    try:
        subprocess.run(["zenity", "--text-info", "--title=Deck ROM Sync",
                         f"--filename={path}", "--width=560", "--height=480"])
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    if offer_enable:
        yes = subprocess.run(
            ["zenity", "--question", "--title=Deck ROM Sync",
             "--text=SSH is not running yet, so the PC app can't connect.\n\n"
             "Enable and start it now?"]).returncode == 0
        if yes:
            ok, msg = enable_sshd()
            subprocess.run(["zenity", "--info" if ok else "--error",
                             "--title=Deck ROM Sync", f"--text={msg}"])


def show_console(text: str, offer_enable: bool) -> None:
    print(text)
    if offer_enable:
        print()
        try:
            answer = input("Enable and start sshd now? [y/N] ").strip().lower()
        except EOFError:
            answer = ""
        if answer == "y":
            ok, msg = enable_sshd()
            print(msg)


def show_info() -> None:
    text, status = build_info_text()
    offer_enable = status != "active"
    if _have("kdialog"):
        show_kdialog(text, offer_enable)
    elif _have("zenity"):
        show_zenity(text, offer_enable)
    else:
        show_console(text, offer_enable)


# ---------------------------------------------------------------- selftest

def _selftest() -> int:
    """Offline checks for the pure-parsing functions, using fixture strings
    captured in the shape real `ip -o addr show` / `systemctl is-active`
    output takes. Lets these be regression-tested without a real Deck.
    Run: python3 deck_connect.py --selftest"""
    ok = True

    fixture_ip = (
        "1: lo    inet 127.0.0.1/8 scope host lo\\       valid_lft forever preferred_lft forever\n"
        "2: eth0    inet 192.168.1.50/24 brd 192.168.1.255 scope global dynamic noprefixroute eth0\\"
        "       valid_lft 86000sec preferred_lft 86000sec\n"
        "3: wlan0    inet 192.168.1.60/24 brd 192.168.1.255 scope global dynamic noprefixroute wlan0\\"
        "       valid_lft 86000sec preferred_lft 86000sec\n"
        "3: wlan0    inet6 fe80::1234/64 scope link\\       valid_lft forever preferred_lft forever\n"
    )
    parsed = parse_ip_addr_output(fixture_ip)
    expect = [("eth0", "192.168.1.50", "Wired"), ("wlan0", "192.168.1.60", "Wi-Fi")]
    if parsed != expect:
        print(f"FAIL parse_ip_addr_output: {parsed!r} != {expect!r}")
        ok = False
    else:
        print("PASS parse_ip_addr_output (typical wired+wifi+ipv6 fixture)")

    empty = parse_ip_addr_output("garbage\nnot an ip line\n")
    if empty != []:
        print(f"FAIL parse_ip_addr_output (no matches): {empty!r}")
        ok = False
    else:
        print("PASS parse_ip_addr_output (no matches)")

    loopback_only = parse_ip_addr_output(
        "1: lo    inet 127.0.0.1/8 scope host lo\\       valid_lft forever preferred_lft forever\n")
    if loopback_only != []:
        print(f"FAIL parse_ip_addr_output (loopback-only): {loopback_only!r}")
        ok = False
    else:
        print("PASS parse_ip_addr_output (loopback-only)")

    for raw, expected in (("active\n", "active"), ("inactive\n", "inactive"), ("", "unknown"),
                           ("failed\n", "failed")):
        got = parse_sshd_status(raw)
        if got != expected:
            print(f"FAIL parse_sshd_status({raw!r}): {got!r} != {expected!r}")
            ok = False
    print("PASS parse_sshd_status (all cases)" if ok else "SOME parse_sshd_status CASES FAILED")

    for iface, expected in (("eth0", "Wired"), ("enp2s0", "Wired"), ("wlan0", "Wi-Fi"),
                             ("wlp1s0", "Wi-Fi"), ("lo", "Loopback"), ("docker0", "Other")):
        got = classify_iface(iface)
        if got != expected:
            print(f"FAIL classify_iface({iface!r}): {got!r} != {expected!r}")
            ok = False
    print("PASS classify_iface (all cases)" if ok else "SOME classify_iface CASES FAILED")

    print("\nAll selftests passed." if ok else "\nSOME SELFTESTS FAILED.")
    return 0 if ok else 1


# --------------------------------------------------------------------- cli

def main() -> int:
    ap = argparse.ArgumentParser(
        description="Deck ROM Sync - Connect Info (runs on the Steam Deck)")
    ap.add_argument("--json", action="store_true",
                     help="print connection info as JSON and exit - no dialogs, no side "
                          "effects (used by the PC app's Show Deck Info button)")
    ap.add_argument("--selftest", action="store_true",
                     help="run offline parsing checks against fixture strings and exit")
    args = ap.parse_args()

    if args.selftest:
        return _selftest()
    if args.json:
        print(json.dumps(gather_info(), indent=2))
        return 0

    show_info()
    return 0


if __name__ == "__main__":
    sys.exit(main())
